application = 
{
    content =
    {
        width = 800,
        height = 1200,
        scale = "letterbox",
    },
}
